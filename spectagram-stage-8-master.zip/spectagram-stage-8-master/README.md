# spectagram-stage-8
project solution for c88
